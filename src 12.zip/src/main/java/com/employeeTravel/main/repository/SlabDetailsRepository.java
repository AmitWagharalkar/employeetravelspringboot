package com.employeeTravel.main.repository;

public class SlabDetailsRepository implements SlabDetailsRepositoryInterface {

}
