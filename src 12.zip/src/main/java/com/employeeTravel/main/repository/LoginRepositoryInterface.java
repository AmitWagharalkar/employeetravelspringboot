package com.employeeTravel.main.repository;

import com.employeeTravel.main.domain.Login;

public interface LoginRepositoryInterface {
	public Login validationUser(Login login);

}
